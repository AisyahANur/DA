<!-- Footer -->
<footer class="main">
	&copy; <?= date('Y');?><strong> Darul 'Amal</strong>. 
   
	
</footer>
